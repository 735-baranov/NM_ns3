/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */

#include <ns3/lora-zigbee-helper.h>
#include <ns3/lora-zigbee-net-device.h>
#include <ns3/simulator.h>
#include <ns3/mobility-model.h>
#include <ns3/single-model-spectrum-channel.h>
#include <ns3/multi-model-spectrum-channel.h>
#include <ns3/propagation-loss-model.h>
#include <ns3/propagation-delay-model.h>
#include <ns3/names.h>

namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("LoRaZiGbeeHelper");

/* ... */
LoRaZiGbeeHelper::LoRaZiGbeeHelper (void) : m_deviceType (LORAZiGbee_DT_END_DEVICE_CLASS_A)
{
  m_channel = CreateObject<SingleModelSpectrumChannel> ();

  Ptr<LogDistancePropagationLossModel> lossModel = CreateObject<LogDistancePropagationLossModel> ();
  m_channel->AddPropagationLossModel (lossModel);

  Ptr<ConstantSpeedPropagationDelayModel> delayModel = CreateObject<ConstantSpeedPropagationDelayModel> ();
  m_channel->SetPropagationDelayModel (delayModel);
}

LoRaZiGbeeHelper::LoRaZiGbeeHelper (bool useMultiModelSpectrumChannel) : m_deviceType (LORAZiGbee_DT_END_DEVICE_CLASS_A)
{
  if (useMultiModelSpectrumChannel)
    {
      m_channel = CreateObject<MultiModelSpectrumChannel> ();
    }
  else
    {
      m_channel = CreateObject<SingleModelSpectrumChannel> ();
    }
  Ptr<LogDistancePropagationLossModel> lossModel = CreateObject<LogDistancePropagationLossModel> ();
  m_channel->AddPropagationLossModel (lossModel);

  Ptr<ConstantSpeedPropagationDelayModel> delayModel = CreateObject<ConstantSpeedPropagationDelayModel> ();
  m_channel->SetPropagationDelayModel (delayModel);
}

LoRaZiGbeeHelper::~LoRaZiGbeeHelper (void)
{
  m_channel = 0;
}

void
LoRaZiGbeeHelper::AddMobility (Ptr<LoRaZiGbeePhy> phy, Ptr<MobilityModel> m)
{
  phy->SetMobility (m);
}

void
LoRaZiGbeeHelper::SetDeviceType (LoRaZiGbeeDeviceType deviceType)
{
  m_deviceType = deviceType;
}

void
LoRaZiGbeeHelper::SetNbRep (uint8_t nbRep)
{
  m_nbRep = nbRep;
}

void
LoRaZiGbeeHelper::EnableLogComponents (enum LogLevel level)
{
  LogComponentEnableAll (LOG_PREFIX_ALL);

  LogComponentEnable ("LoRaZiGbeeSpectrumValueHelper", level);
  LogComponentEnable ("LoRaZiGbeePhy", level);
  LogComponentEnable ("LoRaZiGbeeGatewayApplication", level);
  LogComponentEnable ("LoRaZiGbeeErrorModel", level);
  LogComponentEnable ("LoRaZiGbeeMac", level);
  LogComponentEnable ("LoRaZiGbeeNetDevice", level);
  LogComponentEnable ("LoRaZiGbeeInterferenceHelper", level);
  LogComponentEnable ("LoRaZiGbeeSpectrumSignalParameters", level);
  LogComponentEnable ("LoRaZiGbeeEndDeviceApplication", level);
  LogComponentEnable ("LoRaZiGbeeFrameHeader", level);
}

NetDeviceContainer
LoRaZiGbeeHelper::Install (NodeContainer c)
{
  NetDeviceContainer devices;
  static uint32_t addressCounter = 1;
  for (NodeContainer::Iterator i = c.Begin (); i != c.End (); i++)
    {
      Ptr<Node> node = *i;

      Ptr<LoRaZiGbeeNetDevice> netDevice = CreateObject<LoRaZiGbeeNetDevice> (m_deviceType);

      netDevice->SetChannel (m_channel); // will also set channel on underlying phy(s)
      netDevice->SetNode (node);

      if (m_deviceType != LORAZiGbee_DT_GATEWAY) {
        netDevice->SetAddress (Ipv4Address(addressCounter++)); // will also set channel on underlying phy(s)
        netDevice->SetAttribute ("NbRep", UintegerValue (m_nbRep)); // set number of repetitions
      }

      node->AddDevice (netDevice);
      devices.Add (netDevice);
    }
  return devices;
}


Ptr<SpectrumChannel>
LoRaZiGbeeHelper::GetChannel (void)
{
  return m_channel;
}

void
LoRaZiGbeeHelper::SetChannel (Ptr<SpectrumChannel> channel)
{
  m_channel = channel;
}

void
LoRaZiGbeeHelper::SetChannel (std::string channelName)
{
  Ptr<SpectrumChannel> channel = Names::Find<SpectrumChannel> (channelName);
  m_channel = channel;
}

int64_t
LoRaZiGbeeHelper::AssignStreams (NetDeviceContainer c, int64_t stream)
{
  int64_t currentStream = stream;
  Ptr<NetDevice> netDevice;
  for (NetDeviceContainer::Iterator i = c.Begin (); i != c.End (); ++i)
    {
      netDevice = (*i);
      Ptr<LoRaZiGbeeNetDevice> lorazigbee = DynamicCast<LoRaZiGbeeNetDevice> (netDevice);
      if (lorazigbee)
        {
          currentStream += lorazigbee->AssignStreams (currentStream);
        }
    }
  return (currentStream - stream);
}
}

