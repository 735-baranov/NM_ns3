/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
#ifndef LORA_ZIGBEE_HELPER_H
#define LORA_ZIGBEE_HELPER_H

#include <ns3/lora-zigbee.h>
#include <ns3/lora-zigbee-phy.h>
#include <ns3/node-container.h>
#include <ns3/net-device-container.h>
#include <ns3/log.h>

namespace ns3 {

/**
 * \brief helps to create LoRaZiGbeeNetDevice objects
 *
 * This class can help to create a large set of similar
 * LoRaZiGbeeNetDevice objects and to configure a large set of
 * their attributes during creation.
 */
class LoRaZiGbeeHelper {
public:
  /**
   * \brief Create a LoRaZiGbee helper in an empty state.  By default, a
   * SingleModelSpectrumChannel is created, with a 
   * LogDistancePropagationLossModel and a ConstantSpeedPropagationDelayModel.
   *
   * To change the channel type, loss model, or delay model, the Get/Set
   * Channel methods may be used.
   */
  LoRaZiGbeeHelper (void);

  /**
   * \brief Create a LoRaZiGbee helper in an empty state with either a
   * SingleModelSpectrumChannel or a MultiModelSpectrumChannel.
   * \param useMultiModelSpectrumChannel use a MultiModelSpectrumChannel if true, a SingleModelSpectrumChannel otherwise
   *
   * A LogDistancePropagationLossModel and a 
   * ConstantSpeedPropagationDelayModel are added to the channel.
   */
  LoRaZiGbeeHelper (bool useMultiModelSpectrumChannel);

  virtual ~LoRaZiGbeeHelper (void);

  /**
   * \brief Get the channel associated to this helper
   * \returns the channel
   */
  Ptr<SpectrumChannel> GetChannel (void);

  /**
   * \brief Set the channel associated to this helper
   * \param channel the channel
   */
  void SetChannel (Ptr<SpectrumChannel> channel);

  /**
   * \brief Set the channel associated to this helper
   * \param channelName the channel name
   */
  void SetChannel (std::string channelName);

  /**
   * \brief Add mobility model to a physical device
   * \param phy the physical device
   * \param m the mobility model
   */
  void AddMobility (Ptr<LoRaZiGbeePhy> phy, Ptr<MobilityModel> m);

  /**
   * \brief Set the device type of the LoRaZiGbeeNetDevice objects created by this helper
   */
  void SetDeviceType (LoRaZiGbeeDeviceType deviceType);

  /**
   * \brief Set the NbRep attribute of the LoRaZiGbeeNetDevice objects created by this helper (only for end device net devices)
   */
  void SetNbRep (uint8_t rep);

  /**
   * \brief Install a LoRaZiGbeeNetDevice and the associated structures (e.g., channel) in the nodes.
   * \param c a set of nodes
   * \returns A container holding the added net devices.
   */
  NetDeviceContainer Install (NodeContainer c);

  /**
   * Assign a fixed random variable stream number to the random variables
   * used by this model. Return the number of streams that have been
   * assigned. The Install() method should have previously been
   * called by the user.
   *
   * \param c NetDeviceContainer of the set of net devices for which the
   *          CsmaNetDevice should be modified to use a fixed stream
   * \param stream first stream index to use
   * \return the number of stream indices assigned by this helper
   */
  int64_t AssignStreams (NetDeviceContainer c, int64_t stream);

  void EnableLogComponents (enum LogLevel level = LOG_LEVEL_ALL);
private:
  // Disable implicit constructors
  /**
   * \brief Copy constructor - defined and not implemented.
   */
  LoRaZiGbeeHelper (LoRaZiGbeeHelper const &);
  /**
   * \brief Copy constructor - defined and not implemented.
   * \returns
   */
  LoRaZiGbeeHelper& operator= (LoRaZiGbeeHelper const &);

private:
  Ptr<SpectrumChannel> m_channel; //!< channel to be used for the devices
  LoRaZiGbeeDeviceType m_deviceType; //!< the device type to use when creating new LoRaZiGbeeNetDevice objects
  uint8_t m_nbRep; //!< number of repetitions for unconfirmed us data (only for end devices)
};

}

#endif /* LORA_ZIGBEE_HELPER_H */
