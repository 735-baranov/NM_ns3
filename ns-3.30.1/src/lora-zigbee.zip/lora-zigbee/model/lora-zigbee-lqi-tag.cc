#include "lora-zigbee-lqi-tag.h"
#include <ns3/integer.h>

namespace ns3 {

NS_OBJECT_ENSURE_REGISTERED (LoRaZiGbeeLqiTag);

TypeId
LoRaZiGbeeLqiTag::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::LoRaZiGbeeLqiTag")
    .SetParent<Tag> ()
    .SetGroupName ("LoRaZiGbee")
    .AddConstructor<LoRaZiGbeeLqiTag> ()
    .AddAttribute ("Lqi", "The lqi of the last packet received",
                   IntegerValue (0),
                   MakeIntegerAccessor (&LoRaZiGbeeLqiTag::Get),
                   MakeIntegerChecker<uint8_t> ())
  ;
  return tid;
}

TypeId
LoRaZiGbeeLqiTag::GetInstanceTypeId (void) const
{
  return GetTypeId ();
}

LoRaZiGbeeLqiTag::LoRaZiGbeeLqiTag (void)
  : m_lqi (0)
{
}

LoRaZiGbeeLqiTag::LoRaZiGbeeLqiTag (uint8_t lqi)
  : m_lqi (lqi)
{
}

uint32_t
LoRaZiGbeeLqiTag::GetSerializedSize (void) const
{
  return sizeof (uint8_t);
}

void
LoRaZiGbeeLqiTag::Serialize (TagBuffer i) const
{
  i.WriteU8 (m_lqi);
}

void
LoRaZiGbeeLqiTag::Deserialize (TagBuffer i)
{
  m_lqi = i.ReadU8 ();
}

void
LoRaZiGbeeLqiTag::Print (std::ostream &os) const
{
  os << "Lqi = " << m_lqi;
}

void
LoRaZiGbeeLqiTag::Set (uint8_t lqi)
{
  m_lqi = lqi;
}

uint8_t
LoRaZiGbeeLqiTag::Get (void) const
{
  return m_lqi;
}

}
