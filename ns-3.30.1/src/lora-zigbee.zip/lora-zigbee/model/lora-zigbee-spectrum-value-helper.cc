#include "lora-zigbee-spectrum-value-helper.h"
#include "lora-zigbee.h"
#include <ns3/log.h>
#include <ns3/spectrum-value.h>

#include <cmath>

namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("LoRaZiGbeeSpectrumValueHelper");

Ptr<SpectrumModel> g_LoRaZiGbeeSpectrumModel; //!< Global object that stores the LoRaZiGbee Spectrum Model

/**
 * \ingroup lorazigbee
 * \brief Helper class used to automatically initialize the LoRaZiGbee Spectrum Model objects
 */
class LoRaZiGbeeSpectrumModelInitializer
{
public:
  LoRaZiGbeeSpectrumModelInitializer(void)
  {
    NS_LOG_FUNCTION (this);

    Bands bands;
    // The three default 125kHz data channels available in EU863-870:
    // 868.10, 868.30 & 868.50MHz
    for (int i = 0; i < 3; i++)
      {
        BandInfo bi;
        bi.fc = 868.10e6 + i * 200.0e3;
        bi.fl = bi.fc - 62.5e3; // 62.5 kHz is half of 125 kHz bandwidth
        bi.fh = bi.fc + 62.5e3;
        bands.push_back (bi);
      }

    // Four 125kHz channels available in EU863-870:
    // 867.10, 867.30 & 867.50 & 867.70MHz
    for (int i = 0; i < 4; i++)
      {
        BandInfo bi;
        bi.fc = 867.10e6 + i * 200.0e3;
        bi.fl = bi.fc - 62.5e3; // 62.5 kHz is half of 125 kHz bandwidth
        bi.fh = bi.fc + 62.5e3;
        bands.push_back (bi);
      }

    // One 125kHz high power (27dBm) channel on 869.525MHz
    {
        BandInfo bi;
        bi.fc = 869.525e6;
        bi.fl = bi.fc - 62.5e3; // 62.5 kHz is half of 125 kHz bandwidth
        bi.fh = bi.fc + 62.5e3;
        bands.push_back (bi);
    }
    g_LoRaZiGbeeSpectrumModel = Create<SpectrumModel> (bands);
  }

} g_LoRaZiGbeeSpectrumModelInitializerInstance; //!< Global object used to initialize the LoRaZiGbee Spectrum Model

/* ... */
LoRaZiGbeeSpectrumValueHelper::LoRaZiGbeeSpectrumValueHelper(void)
{
  NS_LOG_FUNCTION (this);
  m_noiseFactor = 1.0;
}

LoRaZiGbeeSpectrumValueHelper::~LoRaZiGbeeSpectrumValueHelper(void)
{
  NS_LOG_FUNCTION (this);
}

Ptr<SpectrumValue>
LoRaZiGbeeSpectrumValueHelper::CreateTxPowerSpectralDensity (double txPower, uint32_t freq)
{
  // TODO: how do we model this for LoRa? The actual center frequency shifts
  // during a symbol period in LoRa, so the power density also shifts during
  // a symbol transmission
  // Should make a simplification: e.g. power density is constant for a 125kHz
  // region and then we have some roll-off nearby... Didn't really find
  // anything in semtech docs, TODO: measure
  // For now: assume constant SPD over 125kHz bandwidth of channel and assume
  // all signal power is concentrated in the channel

  NS_LOG_FUNCTION (this);
  Ptr<SpectrumValue> txPsd = Create <SpectrumValue> (g_LoRaZiGbeeSpectrumModel);

  // txPower is expressed in dBm. We must convert it into natural unit (W).
  txPower = pow (10.0, (txPower - 30) / 10);

  double txPowerDensity = txPower / 125e3;

  (*txPsd)[LoRaZiGbeeSpectrumValueHelper::GetPsdIndexForCenterFrequency(freq)] = txPowerDensity;

  return txPsd;
}

Ptr<SpectrumValue>
LoRaZiGbeeSpectrumValueHelper::CreateNoisePowerSpectralDensity (uint32_t freq)
{
  // TODO
  NS_LOG_FUNCTION (this);
  Ptr<SpectrumValue> noisePsd = Create <SpectrumValue> (g_LoRaZiGbeeSpectrumModel);

  static const double BOLTZMANN = 1.3803e-23;
  // Nt  is the power of thermal noise in W
  double Nt = BOLTZMANN * 290.0;
  // noise Floor (W) which accounts for thermal noise and non-idealities of the receiver
  double noisePowerDensity = m_noiseFactor * Nt;

  (*noisePsd)[LoRaZiGbeeSpectrumValueHelper::GetPsdIndexForCenterFrequency(freq)] = noisePowerDensity;

  return noisePsd;
}

uint32_t
LoRaZiGbeeSpectrumValueHelper::GetPsdIndexForCenterFrequency(uint32_t freq)
{
  NS_LOG_FUNCTION ("LoRaZiGbeeSpectrumValueHelper::GetPsdIndexForCenterFrequency");

  for (uint8_t i = 0; i < LoRaZiGbee::m_supportedChannels.size (); i++) {
    if (freq == LoRaZiGbee::m_supportedChannels[i].m_fc) {
      return i;
    }
  }

  NS_LOG_ERROR ("LoRaZiGbeeSpectrumValueHelper::GetPsdIndexForCenterFrequency: " << "Invalid center frequency:" << freq);
  NS_ASSERT(0);

  return LoRaZiGbee::m_supportedChannels.size ();
}

double
LoRaZiGbeeSpectrumValueHelper::TotalAvgPower (Ptr<const SpectrumValue> psd, uint32_t freq)
{
  NS_LOG_FUNCTION (psd);
  double totalAvgPower = 0.0;

  NS_ASSERT (psd->GetSpectrumModel () == g_LoRaZiGbeeSpectrumModel);

  // numerically integrate to get area under psd using 125kHz resolution

  totalAvgPower += (*psd)[LoRaZiGbeeSpectrumValueHelper::GetPsdIndexForCenterFrequency(freq)];
  totalAvgPower *= 125e3;

  return totalAvgPower;
}

} // namespace ns3
