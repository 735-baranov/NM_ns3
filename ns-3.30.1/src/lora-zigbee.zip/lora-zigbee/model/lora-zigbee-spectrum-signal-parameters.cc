#include "lora-zigbee-spectrum-signal-parameters.h"
#include <ns3/log.h>

namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("LoRaZiGbeeSpectrumSignalParameters");

LoRaZiGbeeSpectrumSignalParameters::LoRaZiGbeeSpectrumSignalParameters (void)
{
  NS_LOG_FUNCTION (this);
}

LoRaZiGbeeSpectrumSignalParameters::LoRaZiGbeeSpectrumSignalParameters (const LoRaZiGbeeSpectrumSignalParameters& p)
  : SpectrumSignalParameters (p)
{
  NS_LOG_FUNCTION (this << &p);
  packet = p.packet;
  channelIndex = p.channelIndex;
  dataRateIndex = p.dataRateIndex;
  codeRate = p.codeRate;
}

Ptr<SpectrumSignalParameters>
LoRaZiGbeeSpectrumSignalParameters::Copy (void)
{
  NS_LOG_FUNCTION (this);
  return Create<LoRaZiGbeeSpectrumSignalParameters> (*this);
}

} // namespace ns3
