#include "lora-zigbee-mac-header.h"
#include "lora-zigbee-mac.h"
#include <ns3/address-utils.h>

namespace ns3 {

NS_OBJECT_ENSURE_REGISTERED (LoRaZiGbeeMacHeader);

LoRaZiGbeeMacHeader::LoRaZiGbeeMacHeader ()
{
  setLoRaZiGbeeMsgType (LoRaZiGbeeMsgType::LORAZiGbee_UNCONFIRMED_DATA_UP);
  setMajor (0);
}

LoRaZiGbeeMacHeader::LoRaZiGbeeMacHeader (LoRaZiGbeeMsgType mType,
                                  uint8_t major)
{
  setLoRaZiGbeeMsgType (mType);
  setMajor (major);
}

LoRaZiGbeeMacHeader::~LoRaZiGbeeMacHeader ()
{
}

LoRaZiGbeeMsgType
LoRaZiGbeeMacHeader::getLoRaZiGbeeMsgType (void) const
{
  return m_msgType;
}

void
LoRaZiGbeeMacHeader::setLoRaZiGbeeMsgType (LoRaZiGbeeMsgType type)
{
  m_msgType = type;
}

uint8_t
LoRaZiGbeeMacHeader::getMajor (void) const
{
  return m_major;
}

void
LoRaZiGbeeMacHeader::setMajor (uint8_t major)
{
  m_major = major;
}

TypeId
LoRaZiGbeeMacHeader::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::LoRaZiGbeeMacHeader")
    .SetParent<Header> ()
    .SetGroupName ("LoRaZiGbee")
    .AddConstructor<LoRaZiGbeeMacHeader> ();
  return tid;
}

TypeId
LoRaZiGbeeMacHeader::GetInstanceTypeId (void) const
{
  return GetTypeId ();
}

void
LoRaZiGbeeMacHeader::Print (std::ostream &os) const
{
  os << "  Message Type = " << (uint32_t) m_msgType << ", Major = " << (uint32_t) m_major;
}

uint32_t
LoRaZiGbeeMacHeader::GetSerializedSize (void) const
{
  /*
   * Each mac header will have 1 octet
   */

  return 1;
}

void
LoRaZiGbeeMacHeader::Serialize (Buffer::Iterator start) const
{
  Buffer::Iterator i = start;

  uint8_t mhdr = 0; // mhdr: msg type (3 bits), RFU (3 bits) and Major version (2 bits)
  mhdr |= (m_msgType & 0x07) << 5;
  mhdr |= (m_major & 0x3);

  i.WriteU8 (mhdr);
}

uint32_t
LoRaZiGbeeMacHeader::Deserialize (Buffer::Iterator start)
{
  Buffer::Iterator i = start;

  uint8_t mhdr = i.ReadU8();
  LoRaZiGbeeMsgType msgType = static_cast<LoRaZiGbeeMsgType>((mhdr >> 5) & 0x07);

  setLoRaZiGbeeMsgType (msgType);
  setMajor ((uint8_t)mhdr & 0x03);

  return 1;
}

bool
LoRaZiGbeeMacHeader::IsConfirmed () const
{
  return (m_msgType == LORAZiGbee_CONFIRMED_DATA_UP || m_msgType == LORAZiGbee_CONFIRMED_DATA_DOWN);
}

bool
LoRaZiGbeeMacHeader::IsDownstream() const
{
  return (m_msgType == LORAZiGbee_UNCONFIRMED_DATA_DOWN || m_msgType == LORAZiGbee_CONFIRMED_DATA_DOWN);
}

bool
LoRaZiGbeeMacHeader::IsUpstream() const
{
  return (m_msgType == LORAZiGbee_CONFIRMED_DATA_UP || m_msgType == LORAZiGbee_UNCONFIRMED_DATA_UP);
}

// ----------------------------------------------------------------------------------------------------------

} //namespace ns3
