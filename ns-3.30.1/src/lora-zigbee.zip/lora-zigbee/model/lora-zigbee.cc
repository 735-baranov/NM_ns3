/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */

#include "lora-zigbee.h"
#include <ns3/log.h>

namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("LoRaZiGbee");

/* ... */

const std::vector<LoRaZiGbeeChannel> LoRaZiGbee::m_supportedChannels = {
  {0, 868100000, 125000, 1},
  {1, 868300000, 125000, 1},
  {2, 868500000, 125000, 1},
  {3, 867100000, 125000, 1},
  {4, 867300000, 125000, 1},
  {5, 867500000, 125000, 1},
  {6, 867700000, 125000, 1},
  // {7, 867900000, 125000, 1}, // sacrifice for high power channel on 869525000
  {7, 869525000, 125000, 3}, // NOTE: always keep this special high power channel as the last element in the m_supportedChannels vector
};

const std::vector<LoRaZiGbeeDataRate> LoRaZiGbee::m_supportedDataRates = {
  {0, LORAZiGbee_SF12, 125000},
  {1, LORAZiGbee_SF11, 125000},
  {2, LORAZiGbee_SF10, 125000},
  {3, LORAZiGbee_SF9, 125000},
  {4, LORAZiGbee_SF8, 125000},
  {5, LORAZiGbee_SF7, 125000},
  {6, LORAZiGbee_SF7, 250000}
}; // other indexes are RFU

uint8_t LoRaZiGbee::m_RW2ChannelIndex = LoRaZiGbee::m_supportedChannels.size () - 1; // high power channel, assume this is last channel in m_supportedChannels
uint8_t LoRaZiGbee::m_RW2DataRateIndex = 0; // lowest spreading factor

uint8_t
LoRaZiGbee::GetRX1DataRateIndex (uint8_t upstreamDRIndex, uint8_t rx1DROffset)
{
  if (rx1DROffset == 0 || rx1DROffset == 1 ||rx1DROffset == 2 ||rx1DROffset == 3 ||rx1DROffset == 4 ||rx1DROffset == 5)
    if (upstreamDRIndex <= rx1DROffset)
      return 0;
    else
      return upstreamDRIndex - rx1DROffset;
  else {
    NS_LOG_WARN ("LoRaZiGbee::GetRX1DataRateIndex Invalid rx1DROffset: " << static_cast<uint16_t>(rx1DROffset));
    return upstreamDRIndex;
  }
}
/****************************************************************************
 ************************ LoRaZiGbeeMsgTypeTag *********************************
 ****************************************************************************/

LoRaZiGbeeMsgTypeTag::LoRaZiGbeeMsgTypeTag () {}

void
LoRaZiGbeeMsgTypeTag::SetMsgType (LoRaZiGbeeMsgType type)
{
  m_msgType = type;
}

LoRaZiGbeeMsgType
LoRaZiGbeeMsgTypeTag::GetMsgType (void) const
{
  return m_msgType;
}

TypeId
LoRaZiGbeeMsgTypeTag::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::LoRaZiGbeeMsgTypeTag")
    .SetParent<Tag> ()
    .SetGroupName("LoRaZiGbee")
    .AddConstructor<LoRaZiGbeeMsgTypeTag> ()
    ;
  return tid;
}

TypeId
LoRaZiGbeeMsgTypeTag::GetInstanceTypeId (void) const
{
  return GetTypeId ();
}

uint32_t
LoRaZiGbeeMsgTypeTag::GetSerializedSize (void) const
{
  return sizeof (uint8_t);
}

void
LoRaZiGbeeMsgTypeTag::Serialize (TagBuffer i) const
{
  i.WriteU8 (m_msgType);
}

void
LoRaZiGbeeMsgTypeTag::Deserialize (TagBuffer i)
{
  m_msgType = static_cast<LoRaZiGbeeMsgType>(i.ReadU8());
}

void
LoRaZiGbeeMsgTypeTag::Print (std::ostream &os) const
{
  os << "LORZiGbee_MAC_MSG_TYPE = " << m_msgType;
}

/****************************************************************************
 *********************** LoRaZiGbeePhyParamsTag ************************************
 ****************************************************************************/

LoRaZiGbeePhyParamsTag::LoRaZiGbeePhyParamsTag () {}

void
LoRaZiGbeePhyParamsTag::SetChannelIndex (uint8_t index)
{
  m_channelIndex = index;
}

uint8_t
LoRaZiGbeePhyParamsTag::GetChannelIndex (void) const
{
  return m_channelIndex;
}

void
LoRaZiGbeePhyParamsTag::SetDataRateIndex (uint8_t index)
{
  m_dataRateIndex = index;
}

uint8_t
LoRaZiGbeePhyParamsTag::GetDataRateIndex (void) const
{
  return m_dataRateIndex;
}

void
LoRaZiGbeePhyParamsTag::SetCodeRate (uint8_t codeRate)
{
  m_codeRate = codeRate;
}

uint8_t
LoRaZiGbeePhyParamsTag::GetCodeRate (void) const
{
  return m_codeRate;
}

TypeId
LoRaZiGbeePhyParamsTag::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::LoRaZiGbeePhyParamsTag")
    .SetParent<Tag> ()
    .SetGroupName("LoRaZiGbee")
    .AddConstructor<LoRaZiGbeePhyParamsTag> ()
    ;
  return tid;
}

TypeId
LoRaZiGbeePhyParamsTag::GetInstanceTypeId (void) const
{
  return GetTypeId ();
}

uint32_t
LoRaZiGbeePhyParamsTag::GetSerializedSize (void) const
{
  return 3 * sizeof (uint8_t);
}

void
LoRaZiGbeePhyParamsTag::Serialize (TagBuffer i) const
{
  i.WriteU8 (m_channelIndex);
  i.WriteU8 (m_dataRateIndex);
  i.WriteU8 (m_codeRate);
}

void
LoRaZiGbeePhyParamsTag::Deserialize (TagBuffer i)
{
  m_channelIndex = i.ReadU8();
  m_dataRateIndex = i.ReadU8();
  m_codeRate = i.ReadU8();
}

void
LoRaZiGbeePhyParamsTag::Print (std::ostream &os) const
{
  os << "LORZiGbee_PHY_RX_PARMS: channelIndex = " << m_channelIndex << ", dataRateIndex = " << m_dataRateIndex << ", codeRate = " << m_codeRate;
}

uint64_t LoRaZiGbeeCounterSingleton::m_counter = -1; // highest possible 64 bit number: 0xffffffffffffffff

//LoRaZiGbeeCounterSingleton*
//LoRaZiGbeeCounterSingleton::GetPtr ()
//{
//  if (!LoRaZiGbeeCounterSingleton::m_ptr)
//    LoRaZiGbeeCounterSingleton::m_ptr = new LoRaZiGbeeCounterSingleton ();
//
//  return LoRaZiGbeeCounterSingleton::m_ptr;
//}
} // namespace ns3


