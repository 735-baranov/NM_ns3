#include <ns3/lora-zigbee.h>
#include <ns3/lora-zigbee-net-device.h>
#include <ns3/lora-zigbee-error-model.h>
#include <ns3/abort.h>
#include <ns3/assert.h>
#include <ns3/node.h>
#include <ns3/log.h>
#include <ns3/spectrum-channel.h>
#include <ns3/pointer.h>
#include <ns3/boolean.h>
#include <ns3/mobility-model.h>
#include <ns3/packet.h>

namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("LoRaZiGbeeNetDevice");

// NS_OBJECT_ENSURE_REGISTERED (LoRaZiGbeeNetDevice);

TypeId
LoRaZiGbeeNetDevice::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::LoRaZiGbeeNetDevice")
    .SetParent<NetDevice> ()
    .SetGroupName ("LoRaZiGbee")
    .AddConstructor<LoRaZiGbeeNetDevice> ()
    .AddAttribute ("Channel", "The channel attached to this device",
                   PointerValue (),
                   MakePointerAccessor (&LoRaZiGbeeNetDevice::DoGetChannel),
                   MakePointerChecker<SpectrumChannel> ())
    .AddAttribute ("Phy", "The PHY layer attached to this device.",
                   PointerValue (),
                   MakePointerAccessor (&LoRaZiGbeeNetDevice::GetPhy,
                                        &LoRaZiGbeeNetDevice::SetPhy),
                   MakePointerChecker<LoRaZiGbeePhy> ())
    .AddAttribute ("Mac", "The MAC layer attached to this device.",
                   PointerValue (),
                   MakePointerAccessor (&LoRaZiGbeeNetDevice::GetMac,
                                        &LoRaZiGbeeNetDevice::SetMac),
                   MakePointerChecker<LoRaZiGbeeMac> ())
    .AddAttribute("NbRep", "The number of repetitions for each UNC uplink message",
                   UintegerValue (1), // default value is one
                   MakeUintegerAccessor (&LoRaZiGbeeNetDevice::m_nbRep),
                   MakeUintegerChecker<uint8_t> (1, 15))
  ;
  return tid;
}

LoRaZiGbeeNetDevice::LoRaZiGbeeNetDevice () : m_deviceType (LORAZiGbee_DT_END_DEVICE_CLASS_A), m_configComplete(false)
{}

LoRaZiGbeeNetDevice::LoRaZiGbeeNetDevice (LoRaZiGbeeDeviceType deviceType)
  : m_deviceType (deviceType), m_configComplete (false)
{
  NS_LOG_FUNCTION (this);

  if (deviceType == LORAZiGbee_DT_END_DEVICE_CLASS_A) {
    uint8_t index = 0;
    m_phy = CreateObject<LoRaZiGbeePhy> (index);
    m_mac = CreateObject<LoRaZiGbeeMac> (index);
    m_macRDC = CreateObject<LoRaZiGbeeMac::LoRaZiGbeeMacRDC> ();
  } else if (deviceType == LORAZiGbee_DT_GATEWAY) {
    uint8_t index = 0;
    for (uint8_t i = 0; i < LoRaZiGbee::m_supportedChannels.size (); i++) {
      for (uint8_t j = 0; j < LoRaZiGbee::m_supportedDataRates.size (); j++) {
        index = i*LoRaZiGbee::m_supportedDataRates.size () + j;
        Ptr<LoRaZiGbeePhy> phy = CreateObject<LoRaZiGbeePhy> (index);
        Ptr<LoRaZiGbeeMac> mac = CreateObject<LoRaZiGbeeMac> (index);
        // index in std::vector is i*LoRaZiGbee::m_supportedDataRates.size () + j
        // phy and mac belong together
        m_phys.push_back (phy);
        m_macs.push_back (mac);
      }
    }
    m_macRDC = CreateObject<LoRaZiGbeeMac::LoRaZiGbeeMacRDC> ();
  }
  CompleteConfig ();
}

LoRaZiGbeeNetDevice::~LoRaZiGbeeNetDevice ()
{
  NS_LOG_FUNCTION (this);
}


void
LoRaZiGbeeNetDevice::DoDispose (void)
{
  NS_LOG_FUNCTION (this);
  if (m_deviceType == LORAZiGbee_DT_END_DEVICE_CLASS_A) {
    m_mac->Dispose ();
    m_phy->Dispose ();
    m_phy = 0;
    m_mac = 0;
  } else if (m_deviceType == LORAZiGbee_DT_GATEWAY) {
    for (uint8_t i = 0; i < m_phys.size(); i++) {
      m_phys[i]->Dispose();
      m_macs[i]->Dispose();
    }

    m_phys.clear ();
    m_macs.clear ();
  }
  m_macRDC = 0;
  m_node = 0;
  // chain up.
  NetDevice::DoDispose ();
}

void
LoRaZiGbeeNetDevice::DoInitialize (void)
{
  NS_LOG_FUNCTION (this);
  if (m_deviceType == LORAZiGbee_DT_END_DEVICE_CLASS_A) {
    m_phy->Initialize ();
    m_mac->Initialize ();
  } else if (m_deviceType == LORAZiGbee_DT_GATEWAY) {
    for (uint8_t i = 0; i < m_phys.size(); i++) {
      m_phys[i]->Initialize();
      m_macs[i]->Initialize();
    }
  }
  NetDevice::DoInitialize ();
}


void
LoRaZiGbeeNetDevice::CompleteConfig (void)
{
  // TODO: this function could share more code the CLASS_A and GW cases
  NS_LOG_FUNCTION (this);

  if (m_deviceType == LORAZiGbee_DT_END_DEVICE_CLASS_A) {
    if (m_mac == 0
        || m_macRDC == 0
        || m_phy == 0
        || m_node == 0
        || m_configComplete)
      {
        return;
      }

    m_mac->SetPhy (m_phy);
    m_mac->SetRDC (m_macRDC);
    m_mac->SetDeviceType (m_deviceType);

    m_mac->SetDataIndicationCallback (MakeCallback (&LoRaZiGbeeNetDevice::DataIndication, this));

    Ptr<MobilityModel> mobility = m_node->GetObject<MobilityModel> ();
    if (!mobility)
      {
        NS_LOG_WARN ("LoRaZiGbeeNetDevice: no Mobility found on the node, probably it's not a good idea.");
      }
    m_phy->SetMobility (mobility);
    Ptr<LoRaZiGbeeErrorModel> model = CreateObject<LoRaZiGbeeErrorModel> ();
    m_phy->SetErrorModel (model);
    m_phy->SetDevice (this);

    m_phy->SetPdDataIndicationCallback (MakeCallback (&LoRaZiGbeeMac::PdDataIndication, m_mac));
    m_phy->SetPdDataDestroyedCallback (MakeCallback (&LoRaZiGbeeMac::PdDataDestroyed, m_mac));
    m_phy->SetPdDataConfirmCallback (MakeCallback (&LoRaZiGbeeMac::PdDataConfirm, m_mac));
    m_phy->SetSetTRXStateConfirmCallback (MakeCallback (&LoRaZiGbeeMac::SetTRXStateConfirm, m_mac));

    m_configComplete = true;
  } else if (m_deviceType == LORAZiGbee_DT_GATEWAY) {
    if (m_macs.size () == 0
        || m_macRDC == 0
        || m_phys.size () == 0
        || m_node == 0
        || m_configComplete)
      {
        return;
      }
    for (uint8_t i = 0; i < m_macs.size (); i++) {
      Ptr<LoRaZiGbeePhy> phy = m_phys[i];
      Ptr<LoRaZiGbeeMac> mac = m_macs[i];
      NS_ASSERT(phy);
      NS_ASSERT(mac);

      // Phy: set channel and data rate for listining (using SetTxConf):
      uint8_t channelIndex = i / LoRaZiGbee::m_supportedDataRates.size();
      uint8_t dataRateIndex = i % LoRaZiGbee::m_supportedDataRates.size();
      if (!phy->SetTxConf (2, channelIndex, dataRateIndex, 3, 8, false, true) ) {
        NS_LOG_ERROR (this << " Phy #" << static_cast<uint16_t>(i) << ": failed setting channelIndex to " << static_cast<uint16_t>(channelIndex) << " and dataRateIndex to " << static_cast<uint16_t>(dataRateIndex));
      }

      mac->SetPhy (phy);
      mac->SetRDC (m_macRDC);
      mac->SetDeviceType (m_deviceType);
      mac->SetDataIndicationCallback (MakeCallback (&LoRaZiGbeeNetDevice::DataIndication, this));

      // Set begin and end tx callbacks (only for gateway)
      mac->SetBeginTxCallback (MakeCallback (&LoRaZiGbeeNetDevice::MacBeginsTx, this));
      mac->SetEndTxCallback (MakeCallback (&LoRaZiGbeeNetDevice::MacEndsTx, this));

      Ptr<MobilityModel> mobility = m_node->GetObject<MobilityModel> ();
      if (!mobility)
        {
          NS_LOG_WARN ("LoRaZiGbeeNetDevice: no Mobility found on the node, probably it's not a good idea.");
        }
      phy->SetMobility (mobility);
      Ptr<LoRaZiGbeeErrorModel> model = CreateObject<LoRaZiGbeeErrorModel> ();
      phy->SetErrorModel (model);
      phy->SetDevice (this);

      phy->SetPdDataIndicationCallback (MakeCallback (&LoRaZiGbeeMac::PdDataIndication, mac));
      phy->SetPdDataDestroyedCallback (MakeCallback (&LoRaZiGbeeMac::PdDataDestroyed,  mac));
      phy->SetPdDataConfirmCallback (MakeCallback (&LoRaZiGbeeMac::PdDataConfirm, mac));
      phy->SetSetTRXStateConfirmCallback (MakeCallback (&LoRaZiGbeeMac::SetTRXStateConfirm, mac));
    }
    m_configComplete = true;
  }
}

void
LoRaZiGbeeNetDevice::SetMac (Ptr<LoRaZiGbeeMac> mac)
{
  NS_LOG_FUNCTION (this);
  if (m_deviceType == LORAZiGbee_DT_END_DEVICE_CLASS_A) {
    m_mac = mac;
    CompleteConfig ();
  } else {
    NS_ASSERT_MSG (0, "Not implemented for non Class A end devices");
  }
}

void
LoRaZiGbeeNetDevice::SetPhy (Ptr<LoRaZiGbeePhy> phy)
{
  NS_LOG_FUNCTION (this);
  if (m_deviceType == LORAZiGbee_DT_END_DEVICE_CLASS_A) {
    m_phy = phy;
    CompleteConfig ();
  } else {
    NS_ASSERT_MSG (0, "Not implemented for non Class A end devices");
  }
}

void
LoRaZiGbeeNetDevice::SetChannel (Ptr<SpectrumChannel> channel)
{
  NS_LOG_FUNCTION (this << channel);
  if (m_deviceType == LORAZiGbee_DT_END_DEVICE_CLASS_A) {
    m_phy->SetChannel (channel);
    channel->AddRx (m_phy);
  } else if (m_deviceType == LORAZiGbee_DT_GATEWAY) {
    for (uint8_t i = 0; i < m_phys.size (); i++) {
      Ptr<LoRaZiGbeePhy> phy = m_phys[i];
      phy->SetChannel (channel);
      channel->AddRx (phy);
    }
  } else {
    NS_ASSERT_MSG (0, "Not implemented for non Class A end devices");
  }
  CompleteConfig ();
}

Ptr<LoRaZiGbeeMac>
LoRaZiGbeeNetDevice::GetMac (void) const
{
   NS_LOG_FUNCTION (this);
  if (m_deviceType == LORAZiGbee_DT_END_DEVICE_CLASS_A) {
    return m_mac;
  } else {
    NS_ASSERT_MSG (0, "Not implemented for non Class A end devices");
    return NULL;
  }
}

std::vector<Ptr<LoRaZiGbeeMac> >
LoRaZiGbeeNetDevice::GetMacs (void) const
{
   NS_LOG_FUNCTION (this);
  if (m_deviceType == LORAZiGbee_DT_GATEWAY) {
    return m_macs;
  } else {
    NS_ASSERT_MSG (0, "Not implemented for non-gateway devices");
    return m_macs;
  }
}

Ptr<LoRaZiGbeePhy>
LoRaZiGbeeNetDevice::GetPhy (void) const
{
  NS_LOG_FUNCTION (this);
  if (m_deviceType == LORAZiGbee_DT_END_DEVICE_CLASS_A) {
    return m_phy;
  } else {
    NS_ASSERT_MSG (0, "Not implemented for non Class A end devices");
    return NULL;
  }
}

std::vector<Ptr<LoRaZiGbeePhy> >
LoRaZiGbeeNetDevice::GetPhys (void) const
{
  NS_LOG_FUNCTION (this);
  if (m_deviceType == LORAZiGbee_DT_GATEWAY) {
    return m_phys;
  } else {
    NS_ASSERT_MSG (0, "Not implemented for non-gateway devices");
    return m_phys;
  }
}
void
LoRaZiGbeeNetDevice::SetIfIndex (const uint32_t index)
{
  NS_LOG_FUNCTION (this << index);
  m_ifIndex = index;
}

uint32_t
LoRaZiGbeeNetDevice::GetIfIndex (void) const
{
  NS_LOG_FUNCTION (this);
  return m_ifIndex;
}

Ptr<Channel>
LoRaZiGbeeNetDevice::GetChannel (void) const
{
  NS_LOG_FUNCTION (this);
  if (m_deviceType == LORAZiGbee_DT_END_DEVICE_CLASS_A) {
    return m_phy->GetChannel ();
  } else if (m_deviceType == LORAZiGbee_DT_GATEWAY) {
    return m_phys[0]->GetChannel (); // assume all phys are on same Channel
  } else {
    NS_ASSERT_MSG (0, "Not implemented");
    return NULL;
  }
}

void
LoRaZiGbeeNetDevice::LinkUp (void)
{
  NS_LOG_FUNCTION (this);
  m_linkUp = true;
  m_linkChanges ();
}

void
LoRaZiGbeeNetDevice::LinkDown (void)
{
  NS_LOG_FUNCTION (this);
  m_linkUp = false;
  m_linkChanges ();
}

Ptr<SpectrumChannel>
LoRaZiGbeeNetDevice::DoGetChannel (void) const
{
  NS_LOG_FUNCTION (this);
  if (m_deviceType == LORAZiGbee_DT_END_DEVICE_CLASS_A) {
    return m_phy->GetChannel ();
  } else if (m_deviceType == LORAZiGbee_DT_GATEWAY) {
    return m_phys[0]->GetChannel (); // assume all phys are on same Channel
  } else {
    NS_ASSERT_MSG (0, "Not implemented");
    return NULL;
  }
}

void
LoRaZiGbeeNetDevice::SetAddress (Address address)
{
  NS_LOG_FUNCTION (this);
  if (m_deviceType == LORAZiGbee_DT_END_DEVICE_CLASS_A) {
    // LoRaZiGbeeMac uses ns3::Ipv4Address to store the 32-bit LoRaZiGbee Network addresses
    m_mac->SetDevAddr (Ipv4Address::ConvertFrom (address));
  } else {
    NS_ASSERT_MSG (0, "Only Class A end devices have a network address");
  }
}

Address
LoRaZiGbeeNetDevice::GetAddress (void) const
{
  NS_LOG_FUNCTION (this);
  if (m_deviceType == LORAZiGbee_DT_END_DEVICE_CLASS_A) {
    return m_mac->GetDevAddr ();
  } else if (m_deviceType == LORAZiGbee_DT_GATEWAY) {
    return Ipv4Address(0xffffffff); // gateways don't really have addresses, but ns3 expects most net devices to have an adresses (TODO: is this true?) so we allocated the all ones address for all gateways ...
  } else {
    NS_ASSERT_MSG (0, "Unsupported LoRaZiGbee device type");
    return Ipv4Address ();
  }
}

bool
LoRaZiGbeeNetDevice::SetMtu (const uint16_t mtu)
{
  NS_ABORT_MSG ("Unsupported");
  return false;
}

uint16_t
LoRaZiGbeeNetDevice::GetMtu (void) const
{
  NS_LOG_FUNCTION (this);
  // TODO: Depends on the spreading factor:
  switch(m_mtuSpreadingFactor) {
  case LORAZiGbee_SF6:
  case LORAZiGbee_SF7:
  case LORAZiGbee_SF8:
	  return 222;
  case LORAZiGbee_SF9:
	  return 115;
  default:
  case LORAZiGbee_SF10:
  case LORAZiGbee_SF11:
  case LORAZiGbee_SF12:
	  return 51;

  }
}

bool
LoRaZiGbeeNetDevice::IsLinkUp (void) const
{
  NS_LOG_FUNCTION (this);
  return m_phy != 0 && m_linkUp;
}

void
LoRaZiGbeeNetDevice::AddLinkChangeCallback (Callback<void> callback)
{
  NS_LOG_FUNCTION (this);
  m_linkChanges.ConnectWithoutContext (callback);
}

bool
LoRaZiGbeeNetDevice::IsBroadcast (void) const
{
  NS_LOG_FUNCTION (this);
  return false;
}

Address
LoRaZiGbeeNetDevice::GetBroadcast (void) const
{
  NS_ABORT_MSG ("Unsupported");
  return Address ();
}

bool
LoRaZiGbeeNetDevice::IsMulticast (void) const
{
  NS_LOG_FUNCTION (this);
  return false;
}

Address
LoRaZiGbeeNetDevice::GetMulticast (Ipv4Address multicastGroup) const
{
  NS_ABORT_MSG ("Unsupported");
  return Address ();
}

Address
LoRaZiGbeeNetDevice::GetMulticast (Ipv6Address addr) const
{
  NS_LOG_FUNCTION (this);
  NS_ABORT_MSG ("Unsupported");
  return Address ();
}

bool
LoRaZiGbeeNetDevice::IsBridge (void) const
{
  NS_LOG_FUNCTION (this);
  return false;
}

bool
LoRaZiGbeeNetDevice::IsPointToPoint (void) const
{
  NS_LOG_FUNCTION (this);
  return false;
}

LoRaZiGbeeDeviceType
LoRaZiGbeeNetDevice::GetDeviceType (void) const
{
  return m_deviceType;
}

//void
//LoRaZiGbeeNetDevice::SetDeviceType (LoRaZiGbeeDeviceType type)
//{
//  m_deviceType = type;
//
//  // LoRaZiGbeeMac uses ns3::Ipv4Address to store the 32-bit LoRaZiGbee Network addresses
//  m_mac->SetDeviceType (type);
//}

bool
LoRaZiGbeeNetDevice::Send (Ptr<Packet> packet, const Address& dest, uint16_t protocolNumber)
{
  // This method basically assumes an 802.3-compliant device, but a raw
  // lorazigbee device does not have an ethertype, and requires specific
  // LoRaZiGbeeDataRequestParams parameters.
  NS_LOG_FUNCTION (this << packet << dest << protocolNumber);

  if (packet->GetSize () > GetMtu ())
    {
      NS_LOG_ERROR ("Fragmentation is needed for this packet, drop the packet ");
      return false;
    }

  LoRaZiGbeePhyParamsTag phyParamsTag;
  uint8_t channelIndex = 0;
  uint8_t dataRateIndex = 0;
  uint8_t codeRate = 0;
  if (packet->RemovePacketTag (phyParamsTag)) {
    channelIndex = phyParamsTag.GetChannelIndex ();
    dataRateIndex = phyParamsTag.GetDataRateIndex ();
    codeRate = phyParamsTag.GetCodeRate ();
  }

  LoRaZiGbeeMsgType msgType = LORAZiGbee_UNCONFIRMED_DATA_UP;
  LoRaZiGbeeMsgTypeTag msgTypeTag;
  if (packet->RemovePacketTag (msgTypeTag)) {
    msgType = msgTypeTag.GetMsgType ();
  }

  LoRaZiGbeeDataRequestParams loRaZiGbeeDataRequestParams;
  loRaZiGbeeDataRequestParams.m_msgType = msgType;
  loRaZiGbeeDataRequestParams.m_loraZiGbeeChannelIndex = channelIndex;
  loRaZiGbeeDataRequestParams.m_loraZiGbeeDataRateIndex = dataRateIndex;
  loRaZiGbeeDataRequestParams.m_loraZiGbeeCodeRate = codeRate;
  loRaZiGbeeDataRequestParams.m_requestHandle = 0; // TODO
  loRaZiGbeeDataRequestParams.m_numberOfTransmissions = 1;
  if (msgType == LORAZiGbee_CONFIRMED_DATA_UP) // note that for LORAZiGbee_CONFIRMED_DATA_DOWN the network server will call ::Send for every retransmission, for end devices ::Send is only called once (app retransmissions vs mac retransmissions)
    loRaZiGbeeDataRequestParams.m_numberOfTransmissions = DEFAULT_NUMBER_US_TRANSMISSIONS;
  else if (msgType == LORAZiGbee_UNCONFIRMED_DATA_UP)
    loRaZiGbeeDataRequestParams.m_numberOfTransmissions = m_nbRep;


  if (m_deviceType == LORAZiGbee_DT_END_DEVICE_CLASS_A) {
    m_mac->sendMACPayloadRequest (loRaZiGbeeDataRequestParams, packet);
    return true;
  } else if (m_deviceType == LORAZiGbee_DT_GATEWAY) {
    // select appropiate MAC/Phy based on channel and data rate of TX
    uint8_t macIndex = 0;
    if (getMACSIndexForChannelAndDataRate (macIndex, channelIndex, dataRateIndex)) {
      if (macIndex >= 0 && macIndex < this->m_macs.size ()) {
        this->m_macs[macIndex]->sendMACPayloadRequest (loRaZiGbeeDataRequestParams, packet);
        return true;
      } else {
        NS_LOG_ERROR (this << " Requested channel/datarate is not supported on gateway: channelIndex = " << channelIndex << ", dataRateIndex = " << dataRateIndex);
        return false;
      }
    } else {
      NS_LOG_ERROR (this << " Requested channel/datarate is not supported on gateway: channelIndex = " << channelIndex << ", dataRateIndex = " << dataRateIndex);
      return false;
    }
  } else {
    NS_LOG_ERROR (this << " Unsupported device type");
    return false;
  }
}

bool
LoRaZiGbeeNetDevice::getMACSIndexForChannelAndDataRate (uint8_t& macsIndex, uint8_t channelIndex, uint8_t dataRateIndex)
{
  if (channelIndex >= LoRaZiGbee::m_supportedChannels.size() || dataRateIndex >= LoRaZiGbee::m_supportedDataRates.size())
    return false;

  macsIndex = channelIndex*LoRaZiGbee::m_supportedDataRates.size() + dataRateIndex;
  return true;
}

void
LoRaZiGbeeNetDevice::MacBeginsTx (Ptr<LoRaZiGbeeMac> macPtr)
{
  NS_ASSERT (m_deviceType == LORAZiGbee_DT_GATEWAY);

  // Switch all MACs (including macPtr) to MAC_UNAVAILABLE state
  for (uint8_t i = 0; i < m_macs.size (); i++) {
    Ptr<LoRaZiGbeeMac> mac = m_macs[i];
    NS_ASSERT(mac);

    // include macPtr, as we need to switch the PHY corresponding to macPtr OFF first, before we can switch it to TX_ON
    // if (mac == macPtr)
    //   continue;

    mac->SwitchToUnavailableState();
  }
}

void
LoRaZiGbeeNetDevice::MacEndsTx (Ptr<LoRaZiGbeeMac> macPtr)
{
  NS_ASSERT (m_deviceType == LORAZiGbee_DT_GATEWAY);

  // Switch all MACs and Phys except macPtr to MAC_IDLE state
  for (uint8_t i = 0; i < m_macs.size (); i++) {
    Ptr<LoRaZiGbeeMac> mac = m_macs[i];
    NS_ASSERT(mac);

    if (mac == macPtr)
      continue;

    mac->SwitchToIdleState ();
  }
}

bool
LoRaZiGbeeNetDevice::CanSendImmediatelyOnChannel (uint8_t channelIndex, uint8_t dataRateIndex)
{
  if (this->m_macRDC) {
    int8_t subBandIndex = this->m_macRDC->GetSubBandIndexForChannelIndex (channelIndex);
    NS_ASSERT (subBandIndex >= 0);
    // step 1: check RDC restrictions
    if (this->m_macRDC->IsSubBandAvailable (subBandIndex)) {
      uint8_t macIndex = 0;
      if (getMACSIndexForChannelAndDataRate (macIndex, channelIndex, dataRateIndex)) {
        // step2: check whether MAC object is in Idle state (could be in TX or unavailable)
        if (this->m_macs[macIndex]->GetLoRaZiGbeeMacState () == MAC_IDLE) {
          // step3: check whether a MAC event is scheduled (MAC state could be scheduled to go to TX state)
          if (!this->m_macs[macIndex]->IsLoRaZiGbeeMacStateRunning ()) {
            return true;
          }
        }
      }
    }
  } else {
    NS_LOG_ERROR (this << " m_macRDC is not set");
    return false;
  }

  return false;
}

bool
LoRaZiGbeeNetDevice::SendFrom (Ptr<Packet> packet, const Address& source, const Address& dest, uint16_t protocolNumber)
{
  NS_ABORT_MSG ("Unsupported");
  return false;
}

Ptr<Node>
LoRaZiGbeeNetDevice::GetNode (void) const
{
  NS_LOG_FUNCTION (this);
  return m_node;
}

void
LoRaZiGbeeNetDevice::SetNode (Ptr<Node> node)
{
  NS_LOG_FUNCTION (this);
  m_node = node;
  CompleteConfig ();
}

bool
LoRaZiGbeeNetDevice::NeedsArp (void) const
{
  NS_LOG_FUNCTION (this);
  return false;
}

void
LoRaZiGbeeNetDevice::SetReceiveCallback (ReceiveCallback cb)
{
  NS_LOG_FUNCTION (this);
  m_receiveCallback = cb;
}

void
LoRaZiGbeeNetDevice::DataIndication (LoRaZiGbeeDataIndicationParams params, Ptr<Packet> pkt)
{
  NS_LOG_FUNCTION (this);

  // Add LoRaZiGbeePhyParamsTag to packet
  LoRaZiGbeePhyParamsTag phyParamsTag;
  phyParamsTag.SetChannelIndex (params.m_channelIndex);
  phyParamsTag.SetDataRateIndex (params.m_dataRateIndex);
  phyParamsTag.SetCodeRate (params.m_codeRate);
  pkt->AddPacketTag (phyParamsTag);

  // Add MsgTypeTag to packet
  LoRaZiGbeeMsgTypeTag msgTypeTag;
  msgTypeTag.SetMsgType (params.m_msgType);
  pkt->AddPacketTag (msgTypeTag);

  Address senderAddress(params.m_endDeviceAddress);

  m_receiveCallback (this, pkt, 0, senderAddress);
}

void
LoRaZiGbeeNetDevice::SetPromiscReceiveCallback (PromiscReceiveCallback cb)
{
  // This method basically assumes an 802.3-compliant device, but a raw
  // lorazigbee device does not have an ethertype, and requires specific
  // LoRaZiGbeeDataRequestParams parameters.
  NS_LOG_WARN ("Unsupported; use LoRaZiGbee MAC APIs instead");
}

bool
LoRaZiGbeeNetDevice::SupportsSendFrom (void) const
{
  NS_LOG_FUNCTION_NOARGS ();
  return false;
}

int64_t
LoRaZiGbeeNetDevice::AssignStreams (int64_t stream)
{
  NS_LOG_FUNCTION (stream);
  int64_t streamIndex = stream;
  if (m_deviceType == LORAZiGbee_DT_END_DEVICE_CLASS_A) {
    streamIndex += m_phy->AssignStreams (stream);
  } else if (m_deviceType == LORAZiGbee_DT_GATEWAY) {
    for (uint8_t i = 0; i < m_phys.size (); i++) {
      Ptr<LoRaZiGbeePhy> phy = m_phys[i];
      streamIndex += phy->AssignStreams (stream + i);
    }
  } else {
    NS_ASSERT_MSG (0, "Not implemented for non Class A end devices");
  }
  NS_LOG_DEBUG ("Number of assigned RV streams:  " << (streamIndex - stream));
  return (streamIndex - stream);
}

} // namespace ns3
