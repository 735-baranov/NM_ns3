#ifndef LORA_ZIGBEE_MAC_H
#define LORA_ZIGBEE_MAC_H

#include "lora-zigbee.h"
#include "lora-zigbee-phy.h"
#include <ns3/object.h>
#include <ns3/traced-callback.h>
#include <ns3/traced-value.h>
#include <ns3/ipv4-address.h>
#include <ns3/nstime.h>
#include <ns3/event-id.h>
#include <ns3/timer.h>
#include <deque>

// Default settings for EU863-870
#define ACK_TIMEOUT 2000000 // in uS
#define ACK_TIMEOUT_RANDOM 1000000 // in uS

namespace ns3 {

class Packet;

/* ... */
/**
 * \ingroup lorazigbee
 *
 * MAC states
 */
typedef enum
{
  MAC_IDLE,              //!< MAC_IDLE
  MAC_TX,                //!< MAC_TX
  MAC_WAITFORRW1,        //!< MAC_WAITFORRW1
  MAC_RW1,               //!< MAC_RW1
  MAC_WAITFORRW2,        //!< MAC_WAITFORRW2
  MAC_RW2,		 //!< MAC_RW2
  //MAC_RX,              //!< MAC_RX
  MAC_ACK_TIMEOUT, 	 //!< MAC_ACK_TIMEOUT, MAC state during which the MAC is waiting for the ACK_TIMEOUT (no TX is allowed during this state)
  MAC_UNAVAILABLE, 	         //!< MAC_UNAVAILABLE, MAC is currently unavailable to perform any operation (e.g. other MAC on same device is currently sending)
} LoRaZiGbeeMacState;

namespace TracedValueCallback {

/**
 * \ingroup LoRaZiGbee
 * TracedValue callback signature for LoRaZiGbeeMacState.
 *
 * \param [in] oldValue original value of the traced variable
 * \param [in] newValue new value of the traced variable
 */
  typedef void (* LoRaZiGbeeMacState)(LoRaZiGbeeMacState oldValue,
                                  LoRaZiGbeeMacState newValue);
}  // namespace TracedValueCallback

/**
 * \ingroup lorazigbee
 *
 * Sub bands and their duty cycle limits
 */
typedef struct LoRaZiGbeeSubBand {
  //std::string subBandName;
  // double fl;
  // double fh;

  uint16_t dutyCycleLimit; // Actual limit is 1 over this value: 10 -> 10%; 100 -> 1%; 1000 => 0.1%
  int8_t maxTXPower;

  Time LastTxFinishedTimestamp; // Simulator Time of when last TX on this sub band finished
  Time timeoff; // Simulator time for timeoff duration on this sub band
} LoRaZiGbeeSubBand;

typedef enum
{
  LORAZiGbee_SUCCESS                = 0,
  LORAZiGbee_NO_ACK                 = 2,
} LoRaZiGbeeMcpsDataConfirmStatus;

/**
 * \ingroup lorazigbee
 *
 * Metadata to be provided when sending a MACPayload message
 */
struct LoRaZiGbeeDataRequestParams
{
  uint8_t m_loraZiGbeeChannelIndex; 	//!< Index of LoRaZiGbee channel
  uint8_t m_loraZiGbeeDataRateIndex; 	//!< Index of LoRa Data Rate
  //LoRaZiGbeeChannel m_loraZiGbeeChannel; 				//!< LoRaZiGbee channel
  //LoRaZiGbeeDataRate m_loraZiGbeeDataRate;
  uint8_t m_loraZiGbeeCodeRate;			//!< Code rate of transmission

  LoRaZiGbeeMsgType m_msgType; 			//!< Message Type
  //uint8_t m_fPort; 			//!< Frame Port
  //uint32_t m_endDeviceAddress; 	//!< End Device Address

  uint32_t m_requestHandle;			//!< Identifier for upper layer of data request
  uint8_t m_numberOfTransmissions;	//!< Number of remaining transmissions for this message

  friend std::ostream& operator<< (std::ostream& os, const LoRaZiGbeeDataRequestParams& p);
};

struct LoRaZiGbeeDataConfirmParams
{
  uint32_t m_requestHandle;			//!< Identifier for upper layer of data request
  LoRaZiGbeeMcpsDataConfirmStatus m_status; //!< The status of the last MSDU transmission
};

/**
 * \ingroup lorazigbee
 *
 * Metadata for a received MACPayload message
 */
struct LoRaZiGbeeDataIndicationParams
{
  uint8_t m_channelIndex;		//!< Channel index of received transmission
  uint8_t m_dataRateIndex;		//!< Data rate index of received transmission
  uint8_t m_codeRate;			//!< Code rate of received transmission

  LoRaZiGbeeMsgType m_msgType; 		//!< Message Type
  Ipv4Address m_endDeviceAddress; 	//!< End Device Address
  uint32_t m_MIC;			//!< MIC
};


/**
 * \ingroup lorazigbee
 *
 * This callback is called immediately before when this MAC object changes its state to the TX state.
 * Note: only for gateways.
 */
class LoRaZiGbeeMac;
typedef Callback<void, Ptr<LoRaZiGbeeMac> > BeginTxCallback;
/**
 * \ingroup lorazigbee
 *
 * This callback is called immediately after when a MAC object has finished a transmission.
 * Note: only for gateways.
 */
typedef Callback<void, Ptr<LoRaZiGbeeMac> > EndTxCallback;

/**
 * \ingroup lorazigbee
 *
 * This callback is called after a McpsDataRequest has been called from
 * the higher layer.  It returns a status of the outcome of the
 * transmission request
 */
typedef Callback<void, LoRaZiGbeeDataConfirmParams> DataConfirmCallback;

/**
 * \ingroup lorazigbee
 *
 * This callback is called after a Mcps has successfully received a
 *  frame and zigbeets to deliver it to the higher layer.
 *
 *  \todo for now, we do not deliver all of the parameters in section
 *  7.1.1.3.1 but just send up the packet.
 */
typedef Callback<void, LoRaZiGbeeDataIndicationParams, Ptr<Packet> > DataIndicationCallback;

/**
 * \ingroup lorazigbee
 *
 * Class that implements the LoRaZiGbee Mac state machine
 * Note that a MAC object is strongly coupled with its underlying PHY, as such
 * there is one LoRaZiGbeeMac per PHY. End devices typically support one MAC/PHY
 * combo, but a gateway supports many MAC/PHY objects.
 */
class LoRaZiGbeeMac : public Object
{

public:
  /**
   * \ingroup lorazigbee
   *
   * Keeping track of RDC limitations accross multiple MAC objects for one lorazigbee node
   */
  class LoRaZiGbeeMacRDC : public Object
  {
  public:
    LoRaZiGbeeMacRDC (void);

    int8_t GetSubBandIndexForChannelIndex (uint8_t channelIndex) const;
    int8_t GetMaxPowerForSubBand (uint8_t subBandIndex) const;
    bool IsSubBandAvailable (uint8_t subBandIndex) const;

    void UpdateRDCTimerForSubBand (uint8_t subBandIndex, Time airTime);

    void ScheduleSubBandTimer (Ptr<LoRaZiGbeeMac> macObj, uint8_t subBandIndex);
    void SubBandTimerExpired (Ptr<LoRaZiGbeeMac> macObj, uint8_t subBandIndex);
  private:
    /**
     * The RDC limitations per sub-band
     */
    std::vector<LoRaZiGbeeSubBand> m_subBands;

    std::vector<EventId> m_subBandTimers;
  };

  /**
   * Get the type ID.
   *
   * \return the object TypeId
   */
  static TypeId GetTypeId (void);

  /**
   * Default constructor.
   */
  LoRaZiGbeeMac (void);
  LoRaZiGbeeMac (uint8_t index);
  virtual ~LoRaZiGbeeMac (void);

  /**
   * Set the underlying PHY for the MAC.
   *
   * \param phy the PHY
   */
  void SetPhy (Ptr<LoRaZiGbeePhy> phy);

  /**
   * Get the underlying PHY of the MAC.
   *
   * \return the PHY
   */
  Ptr<LoRaZiGbeePhy> GetPhy (void);

  /**
   * Set the LoRaZiGbeeMacRDC object of this MAC.
   *
   * \param macRDC the RDC object
   */
  void SetRDC (Ptr<LoRaZiGbeeMacRDC> macRDC);

  void SetLoRaZiGbeeMacState (LoRaZiGbeeMacState macState);
  LoRaZiGbeeMacState GetLoRaZiGbeeMacState () const  { return this->m_LoRaZiGbeeMacState; }
  bool IsLoRaZiGbeeMacStateRunning () const { return this->m_setMacState.IsRunning (); }

  void ChangeMacState (LoRaZiGbeeMacState newState);

  void SetDataIndicationCallback (DataIndicationCallback c);

  void SetDataConfirmCallback (DataConfirmCallback c);

  void SetBeginTxCallback (BeginTxCallback c);
  void SetEndTxCallback (EndTxCallback c);

  void SwitchToUnavailableState ();
  void SwitchToIdleState ();

  void PdDataDestroyed (void);
  void PdDataIndication (uint32_t phyPayloadLength, Ptr<Packet> p, uint8_t lqi, uint8_t channelIndex, uint8_t dataRateIndex, uint8_t codeRate);

  /**
   *  Report status of Phy TRX state switch to MAC
   *  @param status of the state switch
   */
  void SetTRXStateConfirm (LoRaZiGbeePhyEnumeration status);

  /**
   *  Confirm the end of transmission of an MPDU to MAC
   *  @param status to report to MAC
   */
  void PdDataConfirm (LoRaZiGbeePhyEnumeration status);

  Ipv4Address GetDevAddr (void) const;
  void SetDevAddr (Ipv4Address);

  LoRaZiGbeeDeviceType GetDeviceType (void) const;
  void SetDeviceType (LoRaZiGbeeDeviceType);

  uint8_t GetIndex (void) const;

  uint8_t GetRX1DROffset (void) const;
  void SetRX1DROffset (uint8_t);

  /**
   *  Request to transfer a MAC payload.
   *
   *  \param params parameters that describe the transmission
   *  \param p the packet to be transmitted
   */
  void sendMACPayloadRequest (LoRaZiGbeeDataRequestParams params, Ptr<Packet> p);

  /**
   * TracedCallback signature for sent packets.
   *
   * \param [in] packet The packet.
   * \param [in] retries The number of retries.
   */
  typedef void (* SentTracedCallback)
    (Ptr<const Packet> packet, uint8_t retries);

  /**
   * Assign a fixed random variable stream number to the random variables
   * used by this model.  Return the number of streams that have been assigned.
   *
   * \param stream first stream index to use
   * \return the number of stream indices assigned by this model
   */
  int64_t AssignStreams (int64_t stream);

protected:
  // Inherited from Object.
  virtual void DoInitialize (void);
  virtual void DoDispose (void);

  void sendTRXStateRequestForIdleMAC ();
  Ptr<Packet> constructPhyPayload (LoRaZiGbeeDataRequestParams params, Ptr<Packet> p);

  void CheckQueue ();
  void CheckRetransmission ();
  void RemoveFirstTxQElement (bool sentPacket);

  bool ConfigurePhyForTX ();

  void SubBandTimerCallback ();

  void OpenRW ();
  void CloseRW ();
  void CheckPhyPreamble ();
  void StartAckTimeoutTimer ();
  void AckTimeoutExpired ();

  //void StartTransmission();
  //void EndTransmission();
private:

  /**
   * The trace source fired when packets are considered as successfully sent
   * or the transmission has been given up.
   *
   * The data should represent: packet, number of retries
   *
   * \see class CallBackTraceSource
   */
  TracedCallback<Ptr<const Packet>, uint8_t> m_sentPktTrace;

  /**
   * The trace source fired when packets come into the "top" of the device
   * at the L3/L2 transition, when being queued for transmission.
   *
   * \see class CallBackTraceSource
   */
  TracedCallback<Ptr<const Packet> > m_macTxEnqueueTrace;

  /**
   * The trace source fired when packets are dequeued from the
   * L3/l2 transmission queue.
   *
   * \see class CallBackTraceSource
   */
  TracedCallback<Ptr<const Packet> > m_macTxDequeueTrace;

  /**
   * The trace source fired when packets are being sent down to L1.
   *
   * \see class CallBackTraceSource
   */
  TracedCallback<Ptr<const Packet> > m_macTxTrace;

  /**
   * The trace source fired when packets where successfully transmitted, that is
   * an acknowledgment was received, if requested, or the packet was
   * successfully sent by L1, if no ACK was requested.
   *
   * \see class CallBackTraceSource
   */
  TracedCallback<Ptr<const Packet> > m_macTxOkTrace;

  /**
   * The trace source fired when packets are dropped due to missing ACKs or
   * because of transmission failures in L1.
   *
   * \see class CallBackTraceSource
   */
  TracedCallback<Ptr<const Packet> > m_macTxDropTrace;

  /**
   * The trace source fired for packets successfully received by the device
   * immediately before being forwarded up to higher layers (at the L2/L3
   * transition).
   *
   * \see class CallBackTraceSource
   */
  TracedCallback<Ptr<const Packet> > m_macRxTrace;

  /**
   * The trace source fired for packets successfully received by the device
   * but dropped before being forwarded up to higher layers (at the L2/L3
   * transition).
   *
   * \see class CallBackTraceSource
   */
  TracedCallback<Ptr<const Packet> > m_macRxDropTrace;

  /**
   * The index of this Mac object in the lorazigbee net device
   */
  uint8_t m_index;

  /**
   * The PHY's associated with this MAC.
   */
  Ptr<LoRaZiGbeePhy> m_phy;

  /*
   * The RDC object belonging to this node
   */
  Ptr<LoRaZiGbeeMacRDC> m_lorazigbeeMacRDC;

  /*
   * Maximum MACPayload size length as per $7.1.6
   */
  const static uint8_t maxMACPayloadSize[]; // defined for LoRaZiGbee DR0 to DR7

  /**
   * The type of device: End Device or Gateway
   */
  LoRaZiGbeeDeviceType m_deviceType;

  /*
   * The offset for the RW1 downstream data rate as per section 7.1.7
   * Only applicable to end devices
   */
  uint8_t m_RX1DROffset;

  /**
   * The current states of the MAC layer. One per Phy.
   */
  TracedValue<LoRaZiGbeeMacState> m_LoRaZiGbeeMacState;

  /**
   * This callback is used to switch off other MACs and PHYs objects, just prior to when this MAC object starts transmision
   * Only for gateways
   * */
  BeginTxCallback m_beginTxCallback;

  /**
   * This callback is used to switch other MACs and PHYs objects back to IDLE, just after when this MAC object ends transmision
   * Only for gateways
   * */
  EndTxCallback m_endTxCallback;

  /**
   * This callback is used to notify incoming packets to the upper layers.
   */
  DataIndicationCallback m_dataIndicationCallback;

  /**
   * This callback is used to report data transmission request status to the
   * upper layers.
   */
  DataConfirmCallback m_dataConfirmCallback;

  /**
   * Helper structure for managing transmission queue elements.
   */
  struct TxQueueElement
  {
    LoRaZiGbeeDataRequestParams lorazigbeeDataRequestParams; //!< Data request Params
    Ptr<Packet> txQPkt;    //!< Queued packet
  };

  /**
   * The transmit queue used by the MAC.
   */
  std::deque<TxQueueElement*> m_txQueue;

  /**
   * The packet which is currently being sent by the MAC layer.
   * Maximum of one packet at a time, even for the Gateway.
   */
  Ptr<Packet> m_txPkt;  // XXX need packet buffer instead of single packet

  /**
   * The number of already used retransmission for the currently transmitted
   * packet.
   */
  uint8_t m_retransmission;

  /**
   * The short device address identifies the end-device with the current
   * network.
   */
  Ipv4Address m_devAddr;

  /**
   * Scheduler event for a deferred MAC state change.
   */
  EventId m_setMacState;

  /**
   * Scheduler event for a preamble detected check.
   */
  EventId m_preambleDetected;

  /**
   * Scheduler event for an Ack timeout that expired
   */
  EventId m_ackTimeOut;

  /**
   * The Time when the last uplink bit was transmitted
   * Only used in class A end devices for calculating the start of RW1 and RW2
   */
  Time m_lastUplinkBitTime;

  /**
   * The random variable used to calculate the random fraction of the Ack
   * time-out timer
   */
  Ptr<UniformRandomVariable> m_ackTimeOutRandomVariable;
}; // class LoRaZiGbeeMac

} // namespace ns3

#endif /* LORA_ZIGBEE_MAC_H */